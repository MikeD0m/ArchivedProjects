<?php
/*
Plugin Name: Michael's Form Plugin
Description: Plugin to handle multiple forms for different tables.
Version: 2.0
Author: Michael Dominguez
*/
//Provider Form
// Provider Form
function provider_form() {
    ob_start(); // Start output buffering to capture HTML
    ?>
    <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
        <label for="first_name">First Name:</label>
        <input type="text" id="first_name" name="first_name" required><br><br>

        <label for="last_name">Last Name:</label>
        <input type="text" id="last_name" name="last_name" required><br><br>

        <label for="phone">Phone Number:</label>
        <input type="text" id="phone" name="phone" pattern="[0-9]+" title="Please enter numbers only" required><br><br>

        <label for="phone_extension">Phone Extension:</label>
        <input type="text" id="phone_extension" name="phone_extension" pattern="[0-9]+" title="Please enter numbers only"><br><br>

        <label for="title">Title:</label>
        <input type="text" id="title" name="title" required><br><br>

        <label for="company">Company Name:</label>
        <input type="text" id="company" name="company" required><br><br>

        <input type="hidden" name="action" value="handle_provider_form">
        <?php wp_nonce_field( 'handle_provider_form_nonce', 'handle_provider_form_nonce' ); ?>
        <input type="submit" value="Submit">
    </form>
    <?php
    return ob_get_clean(); // Return the captured HTML content
}

// Hook to display form shortcode [provider_form]
add_shortcode( 'provider_form', 'provider_form' );

// Function to handle form submission
function handle_provider_form() {
    if ( isset( $_POST['handle_provider_form_nonce'] ) && wp_verify_nonce( $_POST['handle_provider_form_nonce'], 'handle_provider_form_nonce' ) ) {
        global $wpdb;

        // Sanitize and validate input
        $first_name = sanitize_text_field( $_POST['first_name'] );
        $last_name = sanitize_text_field( $_POST['last_name'] );
        $phone = sanitize_text_field( $_POST['phone'] );
        $phone_extension = isset( $_POST['phone_extension'] ) ? absint( $_POST['phone_extension'] ) : null; // Convert to integer if provided
        $title = sanitize_text_field( $_POST['title'] );
        $company = sanitize_text_field( $_POST['company'] );
        $provider_credits = 0; // Example value, adjust as per your logic

        // Insert data into Solution_Providers table
        $table_name = $wpdb->prefix . 'Solution_Providers';

        $wpdb->insert(
            $table_name,
            array(
                'First_name' => $first_name,
                'Last_name' => $last_name,
                'Phone' => $phone,
                'Phone_extension' => $phone_extension,
                'Title' => $title,
                'Company' => $company,
                'Provider_credits' => $provider_credits,
            ),
            array(
                '%s', // First_name
                '%s', // Last_name
                '%s', // Phone 
                '%d', // Phone_extension
                '%s', // Title
                '%s', // Company
                '%d', // Provider_credits
            )
        );

        // Optionally, redirect the user after submission
        wp_redirect( home_url() );
        exit;
    } else {
        // Nonce verification failed; handle the error or redirect as needed
        wp_die( 'Nonce verification failed' );
    }
}

// Hook into admin_post action hook for Form 1
add_action( 'admin_post_handle_provider_form', 'handle_provider_form' );
add_action( 'admin_post_nopriv_handle_provider_form', 'handle_provider_form' ); // For non-logged in users


//project form
function project_form() {
    ob_start(); // Start output buffering to capture HTML
    $tags = ['Operations', 'Innovation', 'Sustainability', 'Technology', 'Marketing', 'Product development', 'Customer service', 'Finance', 'Human resources', 'Sales']; // Define your tags here
    $campaigns = ['AWS', 'Cloud Migration', 'Digital Transformation','Customer Engagement','Cybersecurity Enhancement']; // Define your campaigns here
    ?>
    <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
        <label for="project_name">Project Name:</label>
        <input type="text" id="project_name" name="project_name" required><br><br>

        <label for="project_timeline">Project Timeline:</label>
        <input type="text" id="project_timeline" name="project_timeline" required><br><br>

        <label for="project_campaign">Project Campaign:</label>
        <select id="project_campaign" name="project_campaign" required>
            <?php foreach ($campaigns as $campaign) : ?>
                <option value="<?php echo esc_attr($campaign); ?>"><?php echo esc_html($campaign); ?></option>
            <?php endforeach; ?>
        </select><br><br>

        <label for="solution_type">Solution Type:</label>
        <input type="text" id="solution_type" name="solution_type" required><br><br>

        <label for="project_brief">Project Brief:</label>
        <textarea id="project_brief" name="project_brief" rows="4" cols="50" required></textarea><br><br>

        <label for="project_goal">Project Goal:</label>
        <textarea id="project_goal" name="project_goal" rows="4" cols="50" required></textarea><br><br>

        <label for="technical_considerations">Technical Considerations:</label>
        <input type="text" id="technical_considerations" name="technical_considerations" required><br><br>

        <label for="project_challenges">Project Challenges:</label>
        <textarea id="project_challenges" name="project_challenges" rows="4" cols="50" required></textarea><br><br>

        <label for="project_solutions">Project Solutions:</label>
        <textarea id="project_solutions" name="project_solutions" rows="4" cols="50" required></textarea><br><br>

        <label for="project_tags">Select Tags:</label><br>
        <?php foreach ($tags as $tag) : ?>
            <input type="checkbox" id="tag_<?php echo esc_attr($tag); ?>" name="project_tags[]" value="<?php echo esc_attr($tag); ?>">
            <label for="tag_<?php echo esc_attr($tag); ?>"><?php echo esc_html($tag); ?></label><br>
        <?php endforeach; ?><br>

        <input type="hidden" name="action" value="handle_project_form">
        <?php wp_nonce_field( 'handle_project_form_nonce', 'handle_project_form_nonce' ); ?>
        <input type="submit" value="Submit">
    </form>
    <?php
    return ob_get_clean(); // Return the captured HTML content
}

// Hook to display form shortcode [provider_form]
add_shortcode( 'project_form', 'project_form' );

// Function to handle form submission
function handle_project_form() {
    if ( isset( $_POST['handle_project_form_nonce'] ) && wp_verify_nonce( $_POST['handle_project_form_nonce'], 'handle_project_form_nonce' ) ) {
        global $wpdb;

        // Sanitize and validate input
        $project_name = sanitize_text_field( $_POST['project_name'] );
        $project_timeline = sanitize_text_field( $_POST['project_timeline'] );
        $project_campaign = sanitize_text_field( $_POST['project_campaign'] );
        $solution_type = sanitize_text_field( $_POST['solution_type'] );
        $project_brief = sanitize_textarea_field( $_POST['project_brief'] );
        $project_goal = sanitize_textarea_field( $_POST['project_goal'] );
        $technical_considerations = sanitize_text_field( $_POST['technical_considerations'] );
        $project_challenges = sanitize_textarea_field( $_POST['project_challenges'] );
        $project_solutions = sanitize_textarea_field( $_POST['project_solutions'] );
        $project_tags = isset($_POST['project_tags']) ? $_POST['project_tags'] : [];

        // Set the current date for project creation date
        $project_creation_date = current_time('mysql');

        // Insert data into Projects table
        $projects_table = $wpdb->prefix . 'project_description';

        $wpdb->insert(
            $projects_table,
            array(
                'Project_name' => $project_name,
                'Project_timeline' => $project_timeline,
                'Project_campaign' => $project_campaign,
                'Solution_type' => $solution_type,
                'Project_brief' => $project_brief,
                'Project_goal' => $project_goal,
                'Technical_considerations' => $technical_considerations,
                'Project_creation_date' => $project_creation_date,
                'Project_challenges' => $project_challenges,
                'Project_solutions' => $project_solutions,
            ),
            array(
                '%s', // project_name
                '%s', // project_timeline
                '%s', // project_campaign
                '%s', // solution_type
                '%s', // project_brief
                '%s', // project_goal
                '%s', // technical_considerations
                '%s', // project_creation_date
                '%s', // project_challenges
                '%s', // project_solutions
            )
        );

        // Get the ID of the newly inserted project
        $project_id = $wpdb->insert_id;

        // Map tags to their corresponding interest IDs
        $interest_map = [
            'Operations' => 1,
            'Innovation' => 2,
            'Sustainability' => 3,
            'Technology' => 4,
            'Marketing' => 5,
            'Product development' => 6,
            'Customer service' => 7,
            'Finance' => 8,
            'Human resources' => 9,
            'Sales' => 10,
        ];

        // Insert selected tags into Project_Interests table
        $project_interests_table = $wpdb->prefix . 'project_interests';

        foreach ($project_tags as $tag) {
            if (array_key_exists($tag, $interest_map)) {
                $interest_id = $interest_map[$tag];
                $wpdb->insert(
                    $project_interests_table,
                    array(
                        'interest_id' => $interest_id,
                        'Project_id' => $project_id,
                    ),
                    array(
                        '%d', // interest_id
                        '%d', // project_id
                    )
                );
            }
        }

        // Optionally, redirect the user after submission
        wp_redirect( home_url() );
        exit;
    } else {
        // Nonce verification failed; handle the error or redirect as needed
        wp_die( 'Nonce verification failed' );
    }
}

// Hook into admin_post action hook for Form 1
add_action( 'admin_post_handle_project_form', 'handle_project_form' );
add_action( 'admin_post_nopriv_handle_project_form', 'handle_project_form' ); // For non-logged in users

//seeker form
function seeker_form() {
    ob_start(); // Start output buffering to capture HTML
    ?>
    <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
        <label for="seeker_company">Company Name:</label>
        <input type="text" id="seeker_company" name="seeker_company" required><br><br>

        <label for="seeker_url">Company URL:</label>
        <input type="text" id="seeker_url" name="seeker_url"><br><br>

        <label for="seeker_location">Location:</label>
        <input type="text" id="seeker_location" name="seeker_location" required><br><br>

        <label for="seeker_industry">Industry:</label>
        <select id="seeker_industry" name="seeker_industry" required>
            <option value="">Select Industry</option>
            <option value="Information Technology">Information Technology</option>
            <option value="Finance">Finance</option>
            <option value="Healthcare">Healthcare</option>
            <option value="Education">Education</option>
            <option value="Manufacturing">Manufacturing</option>
        </select><br><br>

        <label for="seeker_employee_count">Employee Count:</label>
        <input type="number" id="seeker_employee_count" name="seeker_employee_count" required><br><br>

        <label for="seeker_revenue">Revenue:</label>
        <input type="text" id="seeker_revenue" name="seeker_revenue"><br><br>

        <label for="seeker_leadership_level">Leadership Level:</label>
        <select id="seeker_leadership_level" name="seeker_leadership_level" required>
            <option value="">Select Leadership Level</option>
            <option value="C-Level">C-Level</option>
            <option value="Director">Director</option>
            <option value="Supervisor">Supervisor</option>
        </select><br><br>

        <label for="seeker_department">Department:</label>
        <select id="seeker_department" name="seeker_department" required>
            <option value="">Select Department</option>
            <option value="Marketing">Marketing</option>
            <option value="Sales">Sales</option>
            <option value="Operations">Operations</option>
            <option value="Human Resources">Human Resources</option>
            <option value="Finance">Finance</option>
        </select><br><br>

        <label for="seeker_name">Name:</label>
        <input type="text" id="seeker_name" name="seeker_name"><br><br>

        <label for="seeker_title">Title:</label>
        <input type="text" id="seeker_title" name="seeker_title"><br><br>

        <label for="seeker_email">Email:</label>
        <input type="email" id="seeker_email" name="seeker_email"><br><br>

        <label for="seeker_phone">Phone:</label>
        <input type="text" id="seeker_phone" name="seeker_phone"><br><br>

        <input type="hidden" name="action" value="handle_seeker_form">
        <?php wp_nonce_field( 'handle_seeker_form_nonce', 'handle_seeker_form_nonce' ); ?>
        <input type="submit" value="Submit">
    </form>
    <?php
    return ob_get_clean(); // Return the captured HTML content
}

// Hook to display form shortcode [seeker_form]
add_shortcode( 'seeker_form', 'seeker_form' );

function handle_seeker_form() {
    if ( isset( $_POST['handle_seeker_form_nonce'] ) && wp_verify_nonce( $_POST['handle_seeker_form_nonce'], 'handle_seeker_form_nonce' ) ) {
        global $wpdb;

        // Sanitize and validate input
        $seeker_company = sanitize_text_field( $_POST['seeker_company'] );
        $seeker_url = sanitize_text_field( $_POST['seeker_url'] );
        $seeker_location = sanitize_text_field( $_POST['seeker_location'] );
        $seeker_industry = sanitize_text_field( $_POST['seeker_industry'] );
        $seeker_employee_count = intval( $_POST['seeker_employee_count'] );
        $seeker_revenue = sanitize_text_field( $_POST['seeker_revenue'] );
        $seeker_leadership_level = sanitize_text_field( $_POST['seeker_leadership_level'] );
        $seeker_department = sanitize_text_field( $_POST['seeker_department'] );
        $seeker_name = sanitize_text_field( $_POST['seeker_name'] );
        $seeker_title = sanitize_text_field( $_POST['seeker_title'] );
        $seeker_email = sanitize_email( $_POST['seeker_email'] );
        $seeker_phone = sanitize_text_field( $_POST['seeker_phone'] );

        // Insert data into Solution_Seekers table
        $table_name = $wpdb->prefix . 'solution_seekers';

        $wpdb->insert(
            $table_name,
            array(
                'Seeker_company' => $seeker_company,
                'Seeker_url' => $seeker_url,
                'Seeker_location' => $seeker_location,
                'Seeker_industry' => $seeker_industry,
                'Seeker_employee_count' => $seeker_employee_count,
                'Seeker_revenue' => $seeker_revenue,
                'Seeker_leadership_level' => $seeker_leadership_level,
                'Seeker_Department' => $seeker_department,
                'Seeker_name' => $seeker_name,
                'Seeker_title' => $seeker_title,
                'Seeker_email' => $seeker_email,
                'Seeker_phone' => $seeker_phone,
                'Seeker_credits' => 0, // Example value, adjust as per your logic
            ),
            array(
                '%s', // Seeker_company
                '%s', // Seeker_url
                '%s', // Seeker_location
                '%s', // Seeker_industry
                '%d', // Seeker_employee_count
                '%s', // Seeker_revenue
                '%s', // Seeker_leadership_level
                '%s', // Seeker_Department
                '%s', // Seeker_name
                '%s', // Seeker_title
                '%s', // Seeker_email
                '%s', // Seeker_phone
                '%d', // Seeker_credits
            )
        );

        // Optionally, redirect the user after submission
        wp_redirect( home_url() );
        exit;
    } else {
        // Nonce verification failed; handle the error or redirect as needed
        wp_die( 'Nonce verification failed' );
    }
}

// Hook into admin_post action hook for seeker form
add_action( 'admin_post_handle_seeker_form', 'handle_seeker_form' );
add_action( 'admin_post_nopriv_handle_seeker_form', 'handle_seeker_form' ); // For non-logged in users

// Shortcode to display project descriptions
function display_projects() {
    global $wpdb;

    $project_descriptions_table = $wpdb->prefix . 'project_description';
    
    // Initialize variables for search and filter
    $search_project_name = isset( $_GET['project_name'] ) ? sanitize_text_field( $_GET['project_name'] ) : '';
    $selected_campaign = isset( $_GET['campaign_type'] ) ? sanitize_text_field( $_GET['campaign_type'] ) : '';
    $selected_interests = isset( $_GET['interests'] ) ? $_GET['interests'] : array();

    // Build SQL query based on filters
    $sql = "SELECT * FROM $project_descriptions_table WHERE 1=1";
    
    if ( ! empty( $search_project_name ) ) {
        $sql .= " AND Project_name LIKE '%%%s%%'";
        $sql = $wpdb->prepare( $sql, $search_project_name );
    }
    
    if ( ! empty( $selected_campaign ) ) {
        $sql .= " AND Project_campaign = %s";
        $sql = $wpdb->prepare( $sql, $selected_campaign );
    }
    
    if ( ! empty( $selected_interests ) ) {
        // Prepare placeholders for interests
        $placeholders = array_fill( 0, count( $selected_interests ), '%d' );
        $placeholders = implode( ',', $placeholders );
        
        // Prepare interest IDs for IN clause
        $interest_ids = array_map( 'intval', $selected_interests );
        
        // Add condition to filter by selected interests
        $sql .= " AND Project_id IN (SELECT Project_id FROM " . $wpdb->prefix . "project_interests WHERE interest_id IN ($placeholders))";
        $sql = $wpdb->prepare( $sql, $interest_ids );
    }

    // Retrieve data from the database
    $project_descriptions = $wpdb->get_results( $sql, ARRAY_A );

    // Retrieve campaign types and interests for dropdowns
    $campaign_types = ['AWS', 'Cloud Migration', 'Digital Transformation', 'Customer Engagement', 'Cybersecurity Enhancement'];
    $interests = $wpdb->get_results( "SELECT * FROM " . $wpdb->prefix . "interests", ARRAY_A );

    // Output HTML for displaying project descriptions with filters
    ob_start();
    ?>
    <style>
    .project-descriptions-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    .project-descriptions-table th,
    .project-descriptions-table td {
        padding: 8px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }
    .project-descriptions-table th {
        background-color: #f2f2f2;
        font-weight: bold;
    }
    .project-descriptions-table tbody tr:hover {
        background-color: #f5f5f5;
    }
    .project-descriptions-form {
        margin-bottom: 20px;
    }
    </style>

    <div class="project-descriptions">
        <h2>Project Descriptions</h2>
        <form method="get" action="">
            <div class="project-descriptions-form">
                <label for="project_name">Project Name:</label>
                <input type="text" id="project_name" name="project_name" value="<?php echo esc_attr( $search_project_name ); ?>">
                
                <label for="campaign_type">Campaign Type:</label>
                <select id="campaign_type" name="campaign_type">
                    <option value="">Select Campaign Type</option>
                    <?php foreach ( $campaign_types as $campaign ) : ?>
                        <option value="<?php echo esc_attr( $campaign ); ?>" <?php selected( $selected_campaign, $campaign ); ?>><?php echo esc_html( $campaign ); ?></option>
                    <?php endforeach; ?>
                </select>
                
                <fieldset>
                    <legend>Interests:</legend>
                    <?php foreach ( $interests as $interest ) : ?>
                        <label>
                            <input type="checkbox" name="interests[]" value="<?php echo esc_attr( $interest['interest_id'] ); ?>" <?php checked( in_array( $interest['interest_id'], $selected_interests ) ); ?>>
                            <?php echo esc_html( $interest['interest_name'] ); ?>
                        </label><br>
                    <?php endforeach; ?>
                </fieldset>
                
                <input type="submit" value="Filter">
            </div>
        </form>
        
        <table class="wp-list-table widefat striped project-descriptions-table">
            <thead>
                <tr>
                    <th>Project ID</th>
                    <th>Project Name</th>
                    <th>Project Timeline</th>
                    <th>Project Campaign</th>
                    <!-- Add more table headers as needed for other columns -->
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $project_descriptions as $project ) : ?>
                    <tr>
                        <td><?php echo esc_html( $project['Project_id'] ); ?></td>
                        <td><?php echo esc_html( $project['Project_name'] ); ?></td>
                        <td><?php echo esc_html( $project['Project_timeline'] ); ?></td>
                        <td><?php echo esc_html( $project['Project_campaign'] ); ?></td>
                        <!-- Add more columns based on your table structure -->
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
    return ob_get_clean();
}

// Register shortcode
add_shortcode( 'display_projects', 'display_projects' );

//Credit form

// Shortcode to display the form for adding credits
function provider_credits_form() {
    ob_start();
    ?>
    <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
        <label for="provider_id">Enter Provider ID:</label>
        <input type="text" id="provider_id" name="provider_id" required><br><br>

        <label>Select Amount:</label><br>
        <button type="submit" name="credits_amount" value="10">Add 10 Credits</button>
        <button type="submit" name="credits_amount" value="20">Add 20 Credits</button>
        <button type="submit" name="credits_amount" value="50">Add 50 Credits</button>
        <button type="submit" name="credits_amount" value="100">Add 100 Credits</button>

        <input type="hidden" name="action" value="handle_credits_form">
        <?php wp_nonce_field( 'handle_credits_form_nonce', 'credits_form_nonce' ); ?>
    </form>
    <?php
    return ob_get_clean();
}

// Register shortcode
add_shortcode( 'provider_credits_form', 'provider_credits_form' );

// Function to handle form submission
function handle_credits_form() {
    if ( isset( $_POST['credits_amount'] ) && isset( $_POST['provider_id'] ) && isset( $_POST['credits_form_nonce'] ) && wp_verify_nonce( $_POST['credits_form_nonce'], 'handle_credits_form_nonce' ) ) {
        // Sanitize and validate inputs
        $provider_id = absint( $_POST['provider_id'] );
        $credits_amount = sanitize_text_field( $_POST['credits_amount'] );

        // Show confirmation page with hidden fields
        ob_start();
        ?>
        <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
            <input type="hidden" name="provider_id" value="<?php echo esc_attr( $provider_id ); ?>">
            <input type="hidden" name="credits_amount" value="<?php echo esc_attr( $credits_amount ); ?>">
            <label>Are you sure you want to add <?php echo esc_html( $credits_amount ); ?> credits?</label><br>
            <button type="submit" name="confirm_action" value="Yes">Yes</button>
            <button type="submit" name="confirm_action" value="No">No</button>
            <input type="hidden" name="action" value="confirm_credits">
            <?php wp_nonce_field( 'confirm_credits_nonce', 'confirm_credits_nonce' ); ?>
        </form>
        <?php
        return ob_get_clean();
    } else {
        // Nonce verification failed or missing required fields
        wp_die( 'Form submission error. Please try again.' );
    }
}

// Hook into admin_post action hook for Form 1
add_action( 'admin_post_handle_credits_form', 'handle_credits_form' );
add_action( 'admin_post_nopriv_handle_credits_form', 'handle_credits_form' ); // For non-logged in users

// Function to handle confirmation and update credits
function confirm_credits() {
    if ( isset( $_POST['confirm_action'] ) && isset( $_POST['provider_id'] ) && isset( $_POST['credits_amount'] ) && isset( $_POST['confirm_credits_nonce'] ) && wp_verify_nonce( $_POST['confirm_credits_nonce'], 'confirm_credits_nonce' ) ) {
        if ( $_POST['confirm_action'] === 'Yes' ) {
            global $wpdb;
            $provider_id = absint( $_POST['provider_id'] );
            $credits_amount = absint( $_POST['credits_amount'] );

            $providers_table = $wpdb->prefix . 'solution_providers';
            $wpdb->query( $wpdb->prepare( "UPDATE $providers_table SET Provider_credits = Provider_credits + %d WHERE Provider_id = %d", $credits_amount, $provider_id ) );

            // Redirect after processing to avoid form resubmission
            wp_redirect( add_query_arg( 'credits_added', 'true' ) );
            exit;
        } else {
            wp_die( 'Action Cancelled' );
        }
    } else {
        // Nonce verification failed or missing required fields
        wp_die( 'Confirmation error. Please try again.' );
    }
}

// Hook into admin_post action hook for Form 2
add_action( 'admin_post_confirm_credits', 'confirm_credits' );
add_action( 'admin_post_nopriv_confirm_credits', 'confirm_credits' ); // For non-logged in users

// Shortcode to handle the form submission and confirmation
function provider_credits_submission_handler() {
    if ( isset( $_GET['credits_added'] ) && $_GET['credits_added'] === 'true' ) {
        return 'Credit successfully added to your balance!';
    } else {
        return provider_credits_form();
    }
}
add_shortcode( 'provider_credits_submission_handler', 'provider_credits_submission_handler' );
